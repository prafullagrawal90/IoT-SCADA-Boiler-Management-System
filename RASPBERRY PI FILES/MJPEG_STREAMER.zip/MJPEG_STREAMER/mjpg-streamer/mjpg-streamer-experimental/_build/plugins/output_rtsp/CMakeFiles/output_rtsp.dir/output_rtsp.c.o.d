plugins/output_rtsp/CMakeFiles/output_rtsp.dir/output_rtsp.c.o: \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/output_rtsp.c \
 /usr/include/stdc-predef.h /usr/include/stdio.h \
 /usr/include/arm-linux-gnueabihf/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/arm-linux-gnueabihf/bits/wordsize.h \
 /usr/include/arm-linux-gnueabihf/bits/timesize.h \
 /usr/include/arm-linux-gnueabihf/sys/cdefs.h \
 /usr/include/arm-linux-gnueabihf/bits/long-double.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs-hard.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/stddef.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/stdarg.h \
 /usr/include/arm-linux-gnueabihf/bits/types.h \
 /usr/include/arm-linux-gnueabihf/bits/typesizes.h \
 /usr/include/arm-linux-gnueabihf/bits/time64.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__fpos_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__mbstate_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__fpos64_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/types/FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/floatn.h \
 /usr/include/arm-linux-gnueabihf/bits/floatn-common.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio.h /usr/include/stdlib.h \
 /usr/include/arm-linux-gnueabihf/bits/waitflags.h \
 /usr/include/arm-linux-gnueabihf/bits/waitstatus.h \
 /usr/include/arm-linux-gnueabihf/sys/types.h \
 /usr/include/arm-linux-gnueabihf/bits/types/clock_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/clockid_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/time_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/timer_t.h \
 /usr/include/arm-linux-gnueabihf/bits/stdint-intn.h \
 /usr/include/endian.h /usr/include/arm-linux-gnueabihf/bits/endian.h \
 /usr/include/arm-linux-gnueabihf/bits/endianness.h \
 /usr/include/arm-linux-gnueabihf/bits/byteswap.h \
 /usr/include/arm-linux-gnueabihf/bits/uintn-identity.h \
 /usr/include/arm-linux-gnueabihf/sys/select.h \
 /usr/include/arm-linux-gnueabihf/bits/select.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sigset_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__sigset_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_timeval.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_timespec.h \
 /usr/include/arm-linux-gnueabihf/bits/pthreadtypes.h \
 /usr/include/arm-linux-gnueabihf/bits/thread-shared-types.h \
 /usr/include/arm-linux-gnueabihf/bits/pthreadtypes-arch.h \
 /usr/include/arm-linux-gnueabihf/bits/atomic_wide_counter.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_mutex.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_rwlock.h \
 /usr/include/alloca.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-bsearch.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-float.h \
 /usr/include/unistd.h /usr/include/arm-linux-gnueabihf/bits/posix_opt.h \
 /usr/include/arm-linux-gnueabihf/bits/environments.h \
 /usr/include/arm-linux-gnueabihf/bits/confname.h \
 /usr/include/arm-linux-gnueabihf/bits/getopt_posix.h \
 /usr/include/arm-linux-gnueabihf/bits/getopt_core.h \
 /usr/include/arm-linux-gnueabihf/bits/unistd_ext.h /usr/include/string.h \
 /usr/include/arm-linux-gnueabihf/bits/types/locale_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__locale_t.h \
 /usr/include/strings.h /usr/include/arm-linux-gnueabihf/sys/ioctl.h \
 /usr/include/arm-linux-gnueabihf/bits/ioctls.h \
 /usr/lib/linux/uapi/arm/asm/ioctls.h /usr/include/asm-generic/ioctls.h \
 /usr/include/linux/ioctl.h /usr/lib/linux/uapi/arm/asm/ioctl.h \
 /usr/include/asm-generic/ioctl.h \
 /usr/include/arm-linux-gnueabihf/bits/ioctl-types.h \
 /usr/include/arm-linux-gnueabihf/sys/ttydefaults.h /usr/include/errno.h \
 /usr/include/arm-linux-gnueabihf/bits/errno.h /usr/include/linux/errno.h \
 /usr/lib/linux/uapi/arm/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h /usr/include/signal.h \
 /usr/include/arm-linux-gnueabihf/bits/signum-generic.h \
 /usr/include/arm-linux-gnueabihf/bits/signum-arch.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sig_atomic_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/siginfo_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__sigval_t.h \
 /usr/include/arm-linux-gnueabihf/bits/siginfo-arch.h \
 /usr/include/arm-linux-gnueabihf/bits/siginfo-consts.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sigval_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sigevent_t.h \
 /usr/include/arm-linux-gnueabihf/bits/sigevent-consts.h \
 /usr/include/arm-linux-gnueabihf/bits/sigaction.h \
 /usr/include/arm-linux-gnueabihf/bits/sigcontext.h \
 /usr/lib/linux/uapi/arm/asm/sigcontext.h \
 /usr/include/arm-linux-gnueabihf/bits/types/stack_t.h \
 /usr/include/arm-linux-gnueabihf/sys/ucontext.h \
 /usr/include/arm-linux-gnueabihf/bits/sigstack.h \
 /usr/include/arm-linux-gnueabihf/bits/sigstksz.h \
 /usr/include/arm-linux-gnueabihf/bits/ss_flags.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_sigstack.h \
 /usr/include/arm-linux-gnueabihf/bits/sigthread.h \
 /usr/include/arm-linux-gnueabihf/bits/signal_ext.h \
 /usr/include/arm-linux-gnueabihf/sys/socket.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_iovec.h \
 /usr/include/arm-linux-gnueabihf/bits/socket.h \
 /usr/include/arm-linux-gnueabihf/bits/socket_type.h \
 /usr/include/arm-linux-gnueabihf/bits/sockaddr.h \
 /usr/lib/linux/uapi/arm/asm/socket.h /usr/include/asm-generic/socket.h \
 /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
 /usr/lib/linux/uapi/arm/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/lib/linux/uapi/arm/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h \
 /usr/lib/linux/uapi/arm/asm/sockios.h /usr/include/asm-generic/sockios.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_osockaddr.h \
 /usr/include/resolv.h /usr/include/arm-linux-gnueabihf/sys/param.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/limits.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/syslimits.h \
 /usr/include/limits.h /usr/include/arm-linux-gnueabihf/bits/posix1_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/arm-linux-gnueabihf/bits/pthread_stack_min-dynamic.h \
 /usr/include/arm-linux-gnueabihf/bits/pthread_stack_min.h \
 /usr/include/arm-linux-gnueabihf/bits/posix2_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/param.h /usr/include/linux/param.h \
 /usr/lib/linux/uapi/arm/asm/param.h /usr/include/asm-generic/param.h \
 /usr/include/netinet/in.h \
 /usr/include/arm-linux-gnueabihf/bits/stdint-uintn.h \
 /usr/include/arm-linux-gnueabihf/bits/in.h /usr/include/arpa/nameser.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/stdint.h \
 /usr/include/stdint.h /usr/include/arm-linux-gnueabihf/bits/wchar.h \
 /usr/include/arpa/nameser_compat.h \
 /usr/include/arm-linux-gnueabihf/bits/types/res_state.h \
 /usr/include/arpa/inet.h /usr/include/arm-linux-gnueabihf/sys/stat.h \
 /usr/include/arm-linux-gnueabihf/bits/stat.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_stat.h \
 /usr/include/getopt.h /usr/include/arm-linux-gnueabihf/bits/getopt_ext.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/arm-linux-gnueabihf/bits/sched.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_sched_param.h \
 /usr/include/arm-linux-gnueabihf/bits/cpu-set.h /usr/include/time.h \
 /usr/include/arm-linux-gnueabihf/bits/time.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_tm.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_itimerspec.h \
 /usr/include/arm-linux-gnueabihf/bits/setjmp.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct___jmp_buf_tag.h \
 /usr/include/fcntl.h /usr/include/arm-linux-gnueabihf/bits/fcntl.h \
 /usr/include/arm-linux-gnueabihf/bits/fcntl-linux.h \
 /usr/include/syslog.h /usr/include/arm-linux-gnueabihf/sys/syslog.h \
 /usr/include/arm-linux-gnueabihf/bits/syslog-path.h \
 /usr/include/dirent.h /usr/include/arm-linux-gnueabihf/bits/dirent.h \
 /usr/include/arm-linux-gnueabihf/bits/dirent_ext.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/../../utils.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/../../mjpg_streamer.h \
 /usr/include/linux/types.h /usr/lib/linux/uapi/arm/asm/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/linux/videodev2.h \
 /usr/include/arm-linux-gnueabihf/sys/time.h \
 /usr/include/linux/v4l2-common.h /usr/include/linux/v4l2-controls.h \
 /usr/include/linux/const.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/../../plugins/input.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/../../plugins/../mjpg_streamer.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_rtsp/../../plugins/output.h
