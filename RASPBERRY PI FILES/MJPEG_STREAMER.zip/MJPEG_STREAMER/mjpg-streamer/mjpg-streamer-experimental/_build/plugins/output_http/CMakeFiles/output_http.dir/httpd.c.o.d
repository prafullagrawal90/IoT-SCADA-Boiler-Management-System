plugins/output_http/CMakeFiles/output_http.dir/httpd.c.o: \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/httpd.c \
 /usr/include/stdc-predef.h /usr/include/string.h \
 /usr/include/arm-linux-gnueabihf/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/arm-linux-gnueabihf/bits/wordsize.h \
 /usr/include/arm-linux-gnueabihf/bits/timesize.h \
 /usr/include/arm-linux-gnueabihf/sys/cdefs.h \
 /usr/include/arm-linux-gnueabihf/bits/long-double.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs.h \
 /usr/include/arm-linux-gnueabihf/gnu/stubs-hard.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/stddef.h \
 /usr/include/arm-linux-gnueabihf/bits/types/locale_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__locale_t.h \
 /usr/include/strings.h /usr/include/arm-linux-gnueabihf/sys/time.h \
 /usr/include/arm-linux-gnueabihf/bits/types.h \
 /usr/include/arm-linux-gnueabihf/bits/typesizes.h \
 /usr/include/arm-linux-gnueabihf/bits/time64.h \
 /usr/include/arm-linux-gnueabihf/bits/types/time_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_timeval.h \
 /usr/include/arm-linux-gnueabihf/sys/select.h \
 /usr/include/arm-linux-gnueabihf/bits/select.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sigset_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__sigset_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_timespec.h \
 /usr/include/arm-linux-gnueabihf/bits/endian.h \
 /usr/include/arm-linux-gnueabihf/bits/endianness.h \
 /usr/include/arm-linux-gnueabihf/sys/types.h \
 /usr/include/arm-linux-gnueabihf/bits/types/clock_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/clockid_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/timer_t.h \
 /usr/include/arm-linux-gnueabihf/bits/stdint-intn.h \
 /usr/include/endian.h /usr/include/arm-linux-gnueabihf/bits/byteswap.h \
 /usr/include/arm-linux-gnueabihf/bits/uintn-identity.h \
 /usr/include/arm-linux-gnueabihf/bits/pthreadtypes.h \
 /usr/include/arm-linux-gnueabihf/bits/thread-shared-types.h \
 /usr/include/arm-linux-gnueabihf/bits/pthreadtypes-arch.h \
 /usr/include/arm-linux-gnueabihf/bits/atomic_wide_counter.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_mutex.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_rwlock.h \
 /usr/include/unistd.h /usr/include/arm-linux-gnueabihf/bits/posix_opt.h \
 /usr/include/arm-linux-gnueabihf/bits/environments.h \
 /usr/include/arm-linux-gnueabihf/bits/confname.h \
 /usr/include/arm-linux-gnueabihf/bits/getopt_posix.h \
 /usr/include/arm-linux-gnueabihf/bits/getopt_core.h \
 /usr/include/arm-linux-gnueabihf/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/stdlib.h \
 /usr/include/arm-linux-gnueabihf/bits/waitflags.h \
 /usr/include/arm-linux-gnueabihf/bits/waitstatus.h \
 /usr/include/arm-linux-gnueabihf/bits/floatn.h \
 /usr/include/arm-linux-gnueabihf/bits/floatn-common.h \
 /usr/include/alloca.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-bsearch.h \
 /usr/include/arm-linux-gnueabihf/bits/stdlib-float.h \
 /usr/include/stdio.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/stdarg.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__fpos_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__mbstate_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__fpos64_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/types/FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_FILE.h \
 /usr/include/arm-linux-gnueabihf/bits/types/cookie_io_functions_t.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/stdio.h /usr/include/ctype.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/arm-linux-gnueabihf/bits/sched.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_sched_param.h \
 /usr/include/arm-linux-gnueabihf/bits/cpu-set.h /usr/include/time.h \
 /usr/include/arm-linux-gnueabihf/bits/time.h \
 /usr/include/arm-linux-gnueabihf/bits/timex.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_tm.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_itimerspec.h \
 /usr/include/arm-linux-gnueabihf/bits/setjmp.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct___jmp_buf_tag.h \
 /usr/include/arm-linux-gnueabihf/bits/pthread_stack_min-dynamic.h \
 /usr/include/arm-linux-gnueabihf/sys/socket.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_iovec.h \
 /usr/include/arm-linux-gnueabihf/bits/socket.h \
 /usr/include/arm-linux-gnueabihf/bits/socket_type.h \
 /usr/include/arm-linux-gnueabihf/bits/sockaddr.h \
 /usr/lib/linux/uapi/arm/asm/socket.h /usr/include/asm-generic/socket.h \
 /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
 /usr/lib/linux/uapi/arm/asm/posix_types.h \
 /usr/include/asm-generic/posix_types.h \
 /usr/lib/linux/uapi/arm/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h \
 /usr/lib/linux/uapi/arm/asm/sockios.h /usr/include/asm-generic/sockios.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_osockaddr.h \
 /usr/include/arpa/inet.h /usr/include/netinet/in.h \
 /usr/include/arm-linux-gnueabihf/bits/stdint-uintn.h \
 /usr/include/arm-linux-gnueabihf/bits/in.h \
 /usr/include/arm-linux-gnueabihf/sys/stat.h \
 /usr/include/arm-linux-gnueabihf/bits/stat.h \
 /usr/include/arm-linux-gnueabihf/bits/struct_stat.h \
 /usr/include/arm-linux-gnueabihf/bits/statx.h /usr/include/linux/stat.h \
 /usr/include/linux/types.h /usr/lib/linux/uapi/arm/asm/types.h \
 /usr/include/asm-generic/int-ll64.h \
 /usr/include/arm-linux-gnueabihf/bits/statx-generic.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_statx_timestamp.h \
 /usr/include/arm-linux-gnueabihf/bits/types/struct_statx.h \
 /usr/include/fcntl.h /usr/include/arm-linux-gnueabihf/bits/fcntl.h \
 /usr/include/arm-linux-gnueabihf/bits/fcntl-linux.h \
 /usr/include/linux/falloc.h /usr/include/netdb.h \
 /usr/include/rpc/netdb.h \
 /usr/include/arm-linux-gnueabihf/bits/types/sigevent_t.h \
 /usr/include/arm-linux-gnueabihf/bits/types/__sigval_t.h \
 /usr/include/arm-linux-gnueabihf/bits/netdb.h /usr/include/errno.h \
 /usr/include/arm-linux-gnueabihf/bits/errno.h /usr/include/linux/errno.h \
 /usr/lib/linux/uapi/arm/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h \
 /usr/include/arm-linux-gnueabihf/bits/types/error_t.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/limits.h \
 /usr/lib/gcc/arm-linux-gnueabihf/12/include/syslimits.h \
 /usr/include/limits.h /usr/include/arm-linux-gnueabihf/bits/posix1_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/arm-linux-gnueabihf/bits/posix2_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/xopen_lim.h \
 /usr/include/arm-linux-gnueabihf/bits/uio_lim.h \
 /usr/include/linux/version.h /usr/include/linux/videodev2.h \
 /usr/include/linux/ioctl.h /usr/lib/linux/uapi/arm/asm/ioctl.h \
 /usr/include/asm-generic/ioctl.h /usr/include/linux/v4l2-common.h \
 /usr/include/linux/v4l2-controls.h /usr/include/linux/const.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../../mjpg_streamer.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../../plugins/input.h \
 /usr/include/syslog.h /usr/include/arm-linux-gnueabihf/sys/syslog.h \
 /usr/include/arm-linux-gnueabihf/bits/syslog-path.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../../plugins/../mjpg_streamer.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../../plugins/output.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../../utils.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/httpd.h \
 /home/raspberrypi/mjpg-streamer/mjpg-streamer-experimental/plugins/output_http/../output_file/output_file.h
